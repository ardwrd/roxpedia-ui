<!doctype html>
<html lang="<?= service('request')->getLocale() ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= lang('Home.meta_title') ?></title>
    <meta name="description" content="<?= lang('Home.meta_description') ?>">
    <meta name="robots" content="index, follow, max-image-preview:large">
    <link rel="canonical" href="<?= site_url('') ?>">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?= lang('Home.og_title') ?>">
    <meta property="og:description" content="<?= lang('Home.og_description') ?>">
    <meta property="og:url" content="<?= site_url('') ?>">
    <meta property="og:image" content="<?= base_url('assets/og-image.png') ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= lang('Home.og_title') ?>">
    <meta name="twitter:description" content="<?= lang('Home.og_description') ?>">
    <meta name="twitter:image" content="<?= base_url('assets/og-image.png') ?>">
    <link rel="icon" href="<?= base_url('favicon.ico') ?>" type="image/x-icon">
    <link rel="apple-touch-icon" href="<?= base_url('apple-touch-icon.png') ?>">
    <meta name="google-site-verification" content="cxt3123s02hc4oV1vvtBet28W6DuOE-sW34bATAtD-c">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-body-tertiary">
    <?php
    $heroTitle = lang('Home.hero_title');

    $toolCards = [
        [
            'href' => site_url('refinesim'),
            'image' => base_url('assets/img/toolcards/refinement.png'),
            'alt' => 'Refine Simulator',
            'title' => lang('Home.card_refine_title'),
            'description' => lang('Home.card_refine_desc'),
            'badge' => lang('Home.badge_new'),
            'badge_class' => 'success',
        ],
        [
            'href' => site_url('dream-sand-conversion'),
            'image' => base_url('assets/img/toolcards/dreamsand.png'),
            'alt' => 'Dream Sand Conversion',
            'title' => lang('Home.card_dreamsand_title'),
            'description' => lang('Home.card_dreamsand_desc'),
            'badge' => lang('Home.badge_new'),
            'badge_class' => 'success',
        ],
        [
            'href' => site_url('mvpminitrackers'),
            'image' => base_url('assets/img/toolcards/mvpmini.png'),
            'alt' => 'MVP & Mini Trackers',
            'title' => lang('Home.card_mvpmini_trackers_title'),
            'description' => lang('Home.card_mvpmini_trackers_desc'),
            'badge' => lang('Home.badge_new'),
            'badge_class' => 'success',
        ],
        [
            'href' => site_url('mvpmini-database'),
            'image' => base_url('assets/img/toolcards/mvpmini.png'),
            'alt' => 'MVP / Mini Database',
            'title' => lang('Home.card_mvpmini_db_title'),
            'description' => lang('Home.card_mvpmini_db_desc'),
            'badge' => lang('Home.badge_new'),
            'badge_class' => 'success',
        ],
        [
            'href' => site_url('rareitemtaxcalc'),
            'image' => base_url('assets/img/toolcards/roxdjp.png'),
            'alt' => 'Exchange Tax Calc',
            'title' => lang('Home.card_exchange_tax_title'),
            'description' => lang('Home.card_exchange_tax_desc'),
            'badge' => lang('Home.badge_updated'),
            'badge_class' => 'warning',
        ],
        [
            'href' => site_url('mining'),
            'image' => base_url('assets/img/toolcards/pickaxe.png'),
            'alt' => 'Mining',
            'title' => lang('Home.card_mining_title'),
            'description' => lang('Home.card_mining_desc'),
            'badge' => lang('Home.badge_updated'),
            'badge_class' => 'warning',
        ],
        [
            'href' => site_url('fishing'),
            'image' => base_url('assets/img/toolcards/fishing.png'),
            'alt' => 'Fishing',
            'title' => lang('Home.card_fishing_title'),
            'description' => lang('Home.card_fishing_desc'),
            'badge' => lang('Home.badge_new'),
            'badge_class' => 'success',
        ],
        [
            'href' => site_url('gardening'),
            'image' => base_url('assets/img/toolcards/gardening.png'),
            'alt' => 'Gardening',
            'title' => lang('Home.card_gardening_title'),
            'description' => lang('Home.card_gardening_desc'),
            'badge' => lang('Home.badge_new'),
            'badge_class' => 'success',
        ],
        [
            'href' => site_url('weapon-awakening'),
            'image' => base_url('assets/img/toolcards/weapon-awakening.png'),
            'alt' => 'Weapon Awakening',
            'title' => lang('Home.card_weapon_awakening_title'),
            'description' => lang('Home.card_weapon_awakening_desc'),
            'badge' => lang('Home.badge_new'),
            'badge_class' => 'success',
        ],
        [
            'href' => site_url('enchantconversion'),
            'image' => base_url('assets/img/toolcards/enchantconv.png'),
            'alt' => 'Enchant Conversion',
            'title' => lang('Home.card_enchant_conversion_title'),
            'description' => lang('Home.card_enchant_conversion_desc'),
            'badge' => lang('Home.badge_rachel'),
            'badge_class' => 'info',
        ],
        [
            'href' => site_url('home-system'),
            'image' => base_url('assets/img/toolcards/home.png'),
            'alt' => 'Home System',
            'title' => lang('Home.card_home_system_title'),
            'description' => lang('Home.card_home_system_desc'),
            'badge' => lang('Home.badge_new'),
            'badge_class' => 'success',
        ],
        [
            'href' => site_url('raids'),
            'image' => base_url('assets/img/toolcards/raids.png'),
            'alt' => 'Trial Illusion',
            'title' => lang('Home.card_trial_illusion_title'),
            'description' => lang('Home.card_trial_illusion_desc'),
            'badge' => lang('Home.badge_new'),
            'badge_class' => 'success',
        ],
        [
            'href' => site_url('shadowsmelt'),
            'image' => base_url('assets/img/toolcards/shadow-equip.png'),
            'alt' => 'Shadow Equipment',
            'title' => lang('Home.card_shadow_equipment_title'),
            'description' => lang('Home.card_shadow_equipment_desc'),
            'badge' => lang('Home.badge_new'),
            'badge_class' => 'success',
        ],
        [
            'href' => site_url('job-database'),
            'image' => base_url('assets/img/toolcards/job_1100.png'),
            'alt' => 'Job Database',
            'title' => lang('Home.card_job_database_title'),
            'description' => lang('Home.card_job_database_desc'),
            'badge' => lang('Home.badge_new'),
            'badge_class' => 'success',
        ],
        [
            'href' => site_url('monsters'),
            'image' => base_url('assets/img/toolcards/monster.png'),
            'alt' => 'Monsters',
            'title' => lang('Home.card_monsters_title'),
            'description' => lang('Home.card_monsters_desc'),
        ],
        [
            'href' => site_url('exam'),
            'image' => base_url('assets/img/toolcards/ox.png'),
            'alt' => 'OX Answers',
            'title' => lang('Home.card_ox_title'),
            'description' => lang('Home.card_ox_desc'),
        ],
        [
            'href' => site_url('petsimulator'),
            'image' => base_url('assets/img/toolcards/pet.png'),
            'alt' => 'Pet Simulator',
            'title' => lang('Home.card_pet_title'),
            'description' => lang('Home.card_pet_desc'),
        ],
        [
            'href' => site_url('npc'),
            'image' => base_url('assets/img/toolcards/npc.png'),
            'alt' => 'NPC Favors',
            'title' => lang('Home.card_npc_title'),
            'description' => lang('Home.card_npc_desc'),
        ],
        [
            'href' => site_url('equiptransfer'),
            'image' => base_url('assets/img/toolcards/equiptrf.png'),
            'alt' => 'Weapon Transfer',
            'title' => lang('Home.card_weapon_transfer_title'),
            'description' => lang('Home.card_weapon_transfer_desc'),
        ],
    ];
    ?>

    <div class="container py-4">
        <?= view('partials/site_header') ?>

        <main>
            <section class="card shadow-sm border-0 mb-4">
                <div class="card-body p-4 p-lg-5">
                    <div class="row">
                        <div class="col-lg-9">
                            <div class="mb-3">
                                <span class="badge rounded-pill text-bg-primary px-3 py-2"><?= lang('Home.hero_badge') ?></span>
                            </div>
                            <h1 class="display-6 fw-semibold lh-sm mb-3">
                                <?= esc($heroTitle) ?>
                            </h1>
                            <p class="text-secondary mb-0 fs-5"><?= lang('Home.hero_description') ?></p>
                        </div>
                    </div>
                </div>
            </section>

            <section class="mb-3">
                <div class="row row-cols-1 row-cols-md-2 row-cols-xl-3 g-4">
                    <?php foreach ($toolCards as $tool): ?>
                        <div class="col">
                            <a href="<?= esc($tool['href']) ?>" class="text-decoration-none text-reset">
                                <div class="card h-100 shadow-sm">
                                    <div class="card-body d-flex flex-column flex-sm-row align-items-center align-items-sm-start gap-3 text-center text-sm-start">
                                        <div class="d-inline-flex align-items-center justify-content-center rounded-4 border bg-body-tertiary flex-shrink-0 overflow-hidden" style="width: 88px; height: 88px;">
                                            <img src="<?= esc($tool['image']) ?>" alt="<?= esc($tool['alt']) ?>" class="img-fluid" style="max-width: 64px; max-height: 64px; width: auto; height: auto; object-fit: contain;">
                                        </div>
                                        <div class="flex-grow-1 w-100" style="min-width: 0;">
                                            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-sm-start gap-2 mb-2">
                                                <h3 class="h6 mb-0"><?= esc($tool['title']) ?></h3>
                                                <?php if (!empty($tool['badge'])): ?>
                                                    <span class="badge text-bg-<?= esc($tool['badge_class']) ?>"><?= esc($tool['badge']) ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <p class="card-text text-secondary small mb-0"><?= esc($tool['description']) ?></p>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        </main>

        <?= view('partials/site_footer') ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
