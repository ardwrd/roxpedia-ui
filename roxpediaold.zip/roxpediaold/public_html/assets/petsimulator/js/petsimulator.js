    document.getElementById('current-year').textContent = new Date().getFullYear();

    // Star limits by rarity
    const starLimits = { white:{min:1,max:5}, purple:{min:3,max:7}, gold:{min:5,max:9} };

    function populateStarDropdown(selectElement, minStar, maxStar) {
      selectElement.innerHTML = '<option value="" disabled selected>Select Star</option>';
      for (let i=minStar; i<=maxStar; i++){
        const opt=document.createElement('option');
        opt.value=i; opt.textContent=`${i}★`;
        selectElement.appendChild(opt);
      }
    }

    document.getElementById('evolutionPetQuality').addEventListener('change', function(){
      const pq=this.value;
      const cur=document.getElementById('currentStar');
      const tgt=document.getElementById('targetStar');
      if (pq in starLimits){
        const {min,max}=starLimits[pq];
        populateStarDropdown(cur,min,max);
        populateStarDropdown(tgt,min,max);
      } else {
        cur.innerHTML = '<option value="" disabled selected>Select Current Star</option>';
        tgt.innerHTML = '<option value="" disabled selected>Select Target Star</option>';
      }
    });

    // Clamp level 1..60
    function clampLevel($el){
      let v=parseInt($el.val(),10); if(isNaN(v)) return;
      if(v<1) v=1; if(v>60) v=60; if(String(v)!==$el.val()) $el.val(v);
    }
    $('#currentPetLevel,#targetPetLevel').on('input', function(){ clampLevel($(this)); });

    // Number format helper
    const fmt = (n)=> Number(n||0).toLocaleString();

    // === NEW: Hitung & render biaya Pet Food (Crystal) ===
    function updatePetFoodCost(petFoodCount){
      const price = parseFloat($('#petFoodPrice').val());
      if (!isFinite(price) || price < 0 || !isFinite(petFoodCount)) {
        $('#petFoodCost').text('—');
        return;
      }
      const total = Math.round(petFoodCount * price);
      $('#petFoodCost').text(fmt(total));
    }

    // ---- EXP ----
    function calculateExp(){
      var petQuality = $('#petQuality').val();
      var currentLevel = $('#currentPetLevel').val();
      var currentExp = $('#currentExpPet').val();
      var targetLevel = $('#targetPetLevel').val();
      var kafraVIP = $('#kafraVIP').is(':checked') ? 'on' : 'off';

      if (!petQuality || !currentLevel || currentExp === '' || !targetLevel) {
        $("#expResult").text("Please provide your pet's data.");
        $("#itemsResult").text("—");
        $("#daysToTarget").text("—");
        $("#daysToMax").text("—");
        $("#petFoodCost").text("—"); // NEW: reset cost
        return;
      }

      // 1) To target
      $.ajax({
        type:"POST",
        url:"<?= site_url('petsimulator/calculate-exp'); ?>",
        data:{
          [CSRF_NAME]: CSRF_HASH,
          petQuality: petQuality,
          currentPetLevel: currentLevel,
          currentExpPet: currentExp,
          targetPetLevel: targetLevel,
          kafraVIP: kafraVIP
        },
        success:function(res){
          if(res.error){
            $("#expResult").text(res.error);
            $("#itemsResult").text("—");
            $("#daysToTarget").text("—");
            $("#daysToMax").text("—");
            $("#petFoodCost").text("—"); // NEW: reset cost on error
            return;
          }

          $("#expResult").text(fmt(res.expNeeded));
          $("#itemsResult").html(
            `Pat: ${fmt(res.itemsNeeded.pat)}<br>`+
            `Heartwarming Pat: ${fmt(res.itemsNeeded.heartwarmingPat)}<br>`+
            `Pet Food: ${fmt(res.itemsNeeded.petFood)}`
          );

          // NEW: Estimasi biaya jika semua Pet Food dibeli
          updatePetFoodCost(Number(res.itemsNeeded?.petFood || 0));

          const need = Number(res.expNeeded||0);
          if(need<=0){
            $("#daysToTarget").html('<span class="text-success">Already reached the target level.</span>');
          }else{
            const dNoVip = Math.ceil(need/1500);
            const dVip   = Math.ceil(need/2500);
            $("#daysToTarget").html(
              `Remaining EXP: <strong>${fmt(need)}</strong><br>`+
              `Non Kafra VIP: <strong>${fmt(dNoVip)} day(s)</strong><br>`+
              `Kafra VIP: <strong>${fmt(dVip)} day(s)</strong>`
            );
          }

          // 2) To Max (Lv 60)
          $.ajax({
            type:"POST",
            url:"<?= site_url('petsimulator/calculate-exp'); ?>",
            data:{
              [CSRF_NAME]: CSRF_HASH,
              petQuality: petQuality,
              currentPetLevel: currentLevel,
              currentExpPet: currentExp,
              targetPetLevel: 60,
              kafraVIP: kafraVIP
            },
            success:function(rm){
              if(rm.error){ $("#daysToMax").text("—"); return; }
              const expMax = Number(rm.expNeeded||0);
              if(expMax<=0){
                $("#daysToMax").html('<span class="text-success">Your pet is already at max level.</span>');
              }else{
                const n = Math.ceil(expMax/1500);
                const v = Math.ceil(expMax/2500);
                $("#daysToMax").html(
                  `Remaining EXP: <strong>${fmt(expMax)}</strong><br>`+
                  `Non Kafra VIP: <strong>${fmt(n)} day(s)</strong><br>`+
                  `Kafra VIP: <strong>${fmt(v)} day(s)</strong>`
                );
              }
            },
            error:function(){ $("#daysToMax").text("—"); }
          });
        },
        error:function(){
          $("#expResult").text("There was an error processing your request.");
          $("#daysToTarget").text("—");
          $("#daysToMax").text("—");
          $("#petFoodCost").text("—"); // NEW: reset cost on ajax error
        }
      });
    }

    // Trigger recalculation on inputs
    $('#petQuality,#currentPetLevel,#currentExpPet,#targetPetLevel,#kafraVIP').on('input change', calculateExp);

    // NEW: Recompute cost when price changes (pakai jumlah pet food terakhir di Items Result)
    $('#petFoodPrice').on('input change', function(){
      const txt = $('#itemsResult').text();
      const match = txt.match(/Pet Food:\s*([\d,\.]+)/i);
      const petFoodCount = match ? parseInt(match[1].replace(/[,.]/g,''),10) : NaN;
      updatePetFoodCost(petFoodCount);
    });

    // ---- Evolution ----
    function calculateEvolution(){
      var petQuality = $('#evolutionPetQuality').val();
      var currentStar = parseInt($('#currentStar').val());
      var targetStar = parseInt($('#targetStar').val());

      if(!petQuality || !currentStar || !targetStar || currentStar >= targetStar){
        $("#evolutionResult").text("Please fill out all fields correctly.");
        $("#totalCost").text("Total cost for Scale and Spirit Stone will be displayed here.");
        return;
      }

      var spiritStonePrices=[], scalePrices=[];
      $('.spiritStonePrice').each(function(){ let p=parseFloat($(this).val()); if(isNaN(p)) p=0; spiritStonePrices.push(p); });
      $('.scalePrice').each(function(){ let p=parseFloat($(this).val()); if(isNaN(p)) p=0; scalePrices.push(p); });

      $.ajax({
        type:"POST",
        url:"<?= site_url('petsimulator/calculate-evolution'); ?>",
        data:{
          [CSRF_NAME]: CSRF_HASH,
          petQuality, currentStar, targetStar,
          spiritStonePrice: spiritStonePrices,
          scalePrice: scalePrices
        },
        success:function(r){
          if(r.error){ $("#evolutionResult").text(r.error); return; }

          let html = `<strong>Total Materials:</strong><br>
            Spirit Stone: ${fmt(r.totalMaterials.spiritStone)}<br>
            Scale: ${fmt(r.totalMaterials.scale)}<br>
            Adv. Pill: ${fmt(r.totalMaterials.advPill)}<br><br>
            <strong>Material Details:</strong><br>`;

          r.materialDetails.forEach(d=>{
            html += `
              <div class="mb-2">
                <strong>${d.level}</strong><br>
                - Spirit Stone: ${fmt(d.spiritStone)} (Cost: ${fmt(d.spiritStoneCost)})<br>
                - Scale: ${fmt(d.scale)} (Cost: ${fmt(d.scaleCost)})<br>
                - Adv. Pill: ${fmt(d.advPill)} (Cost: ${fmt(d.advPillCost)} ${d.advPillCurrency})<br>
              </div>`;
          });

          $("#evolutionResult").html(html);

          $("#totalCost").html(`
            <strong>Total Cost:</strong><br>
            Spirit Stone Cost: ${fmt(r.totalCost.spiritStone)}<br>
            Scale Cost: ${fmt(r.totalCost.scale)}<br>
            Adv. Pill Cost:<br>
            - Crystal: ${fmt(r.totalCost.advPill.Crystal)}<br>
            - Diamond: ${fmt(r.totalCost.advPill.Diamond)}
          `);
        },
        error:function(){ $("#evolutionResult").text("There was an error processing your request."); }
      });
    }
    $('#evolutionPetQuality,#currentStar,#targetStar,.spiritStonePrice,.scalePrice').on('input change', calculateEvolution);

    // ---- Release ----
    function calculatePetRelease(){
      var petQuality = $('#petReleaseQuality').val();
      var petLevel = $('#petReleaseLevel').val();
      var petStar = $('#petStar').val();
      var isEvolved = $('#isEvolved').is(':checked') ? 'on' : 'off';

      if(!petQuality || !petLevel || !petStar){
        $("#releaseResult").text("Please provide your pet's data to calculate the release rewards.");
        return;
      }

      $.ajax({
        type:"POST",
        url:"<?= site_url('petsimulator/calculate-pet-release'); ?>",
        data:{
          [CSRF_NAME]: CSRF_HASH,
          petReleaseQuality: petQuality,
          petReleaseLevel: petLevel,
          petStar: petStar,
          isEvolved: isEvolved
        },
        success:function(r){
          if(r.error){ $("#releaseResult").text(r.error); return; }
          $("#releaseResult").html(`
            <div class="row g-3">
              <div class="col-sm-6">
                <div class="border rounded p-3 h-100">
                  <div class="text-secondary small">Pet Food</div>
                  <div class="fw-semibold">${fmt(r.petFood)}</div>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="border rounded p-3 h-100">
                  <div class="text-secondary small">Advancement Box</div>
                  <div class="fw-semibold">${fmt(r.advancementBox)}</div>
                </div>
              </div>
            </div>
          `);
        },
        error:function(){ $("#releaseResult").text("There was an error processing your request."); }
      });
    }
    $('#petReleaseQuality,#petReleaseLevel,#petStar,#isEvolved').on('input change', calculatePetRelease);

    // ---- Pet Database (pakai data penuh milikmu tanpa perubahan) ----
    const petDatabase = [
      {
        rarity: "white",
        name: "Poring",
        talent: "Jumps up and slams the target, dealing 96%(+24% per ★↑) Neutral damage of a type that matches their own. Has a 16%(+4% per ★↑) chance to stun the target for 1 second. Cooldown is 12 seconds."
      },
      {
        rarity: "white",
        name: "Lunatic",
        talent: "Charges at the target, dealing 96%(+24% per ★↑) Neutral damage of a type that matches their own. Has a 16%(+4% per ★↑) chance to make the target bleed for 3 seconds. Cooldown is 12 seconds."
      },
      {
        rarity: "white",
        name: "Rocker",
        talent: "Rocker strums the guitar, emitting listless notes that have a 16%(+4% per ★↑) chance to confuse enemies within 3 meters of their master for 6 seconds. Cooldown is 18 seconds."
      },
      {
        rarity: "white",
        name: "Baby Desert Wolf",
        talent: "Angrily howls at the enemy and intimidates them, decreasing the Final Physical Damage Reduction and Final Magic Damage Reduction of all enemies within 3 meters of their master by 16%(+4% per ★↑) each for 6 seconds. Cooldown is 18 seconds. This effect cannot stack."
      },
      {
        rarity: "white",
        name: "Hornet",
        talent: "Shoots a poisonous needle at the enemy, dealing Neutral damage of a type that matches their own equal to 1.6%(+0.4% per ★↑) of the target's Max HP. Cooldown is 12 seconds. Not effective against Bosses, MVPs, and Minis."
      },
      {
        rarity: "white",
        name: "Familiar",
        talent: "Grants their master a Lifesteal buff, increasing their Physical Lifesteal and Magic Lifesteal by 8%(+2% per ★↑) each for 6 seconds. Cooldown is 24 seconds. This effect cannot stack."
      },
      {
        rarity: "white",
        name: "Whisper",
        talent: "Grants 1 stack of Phantom Flash to its master, increasing Final Dodge and Final Anti-Crit by 16%(+4% per ★↑) for 4s. 12-second cooldown."
      },
      {
        rarity: "white",
        name: "Zombie",
        talent: "Emits a stench of putrefaction, with a 16%(+4% per ★↑) chance of dealing Bleed to all enemies within a 3-meter range for 3s. 12-second cooldown."
      },
      {
        rarity: "white",
        name: "Dustiness",
        talent: "Launches a strike against the target, dealing 240%(+60% per ★↑) Wind attribute Adaptive Damage. 3-second cooldown."
      },
      {
        rarity: "white",
        name: "Roda Frog",
        talent: "Sticks out its forked tongue and sprays the target, dealing 240%(+60% per ★↑) Water attribute Adaptive Damage. 3-second cooldown."
      },
      {
        rarity: "white",
        name: "Anacondaq",
        talent: "Tears savagely at the target, dealing 240%(+60% per ★↑) Poison attribute Adaptive Damage. 3-second cooldown."
      },
      {
        rarity: "white",
        name: "Slime",
        talent: "Devours the target. If the target is a monster, it will die at once. If the target is a player, the target will be spit out after 2 seconds. Restores 12%(+3% per ★↑) Max HP of the owner, and removes owner's debuffs and grants immunity to debuffs for the next 4 seconds (except for debuffs that cannot be removed). This skill is not effective against Bosses, MVPs and Minis. Cooldown is 24 seconds. Devouring-type skills cannot be cast on the same target for 24 seconds."
      },
      {
        rarity: "white",
        name: "Fairy Rabbit",
        talent: "Moon Rabbit awakens Moon's Aura to increase 4%(+1% per ★↑) Final Damage Bonus and Final Damage Reduction of their master and their party members for 12 seconds, stacking up to 5 times, with a 36-second cooldown."
      },
      {
        rarity: "white",
        name: "Vadon",
        talent: "The Vadon pinches the target with its claws, dealing 240%(+60% per ★↑) Adaptive Water Damage. Cooldown: 3 seconds."
      },
      {
        rarity: "white",
        name: "Marse",
        talent: "Sprays squid ink to surrounding targets within 3 meters. Has a 16%(+4% per ★↑) chance to Blind them for 3 seconds. Cooldown: 12 seconds."
      },
      {
        rarity: "white",
        name: "Andre",
        talent: "Bites the target, dealing 240%(+60% per ★↑) Adaptive Earth Damage. Cooldown: 3 seconds."
      },
      {
        rarity: "white",
        name: "Mummy",
        talent: "Deals 80%(+20% per ★↑) Adaptive Undead Damage every second to enemies within 4 meters of the pet for 3 seconds. Cooldown: 12 seconds."
      },
      {
        rarity: "white",
        name: "Orc Warrior",
        talent: "Enables a 16%(+4% per ★↑) chance to slow nearby enemies within 3 meters of it by 50% for 3 seconds. Cooldown: 12 seconds."
      },
      {
        rarity: "white",
        name: "Brilight",
        talent: "Bites the target, dealing 240%(+60% per ★↑) Adaptive Fire Damage. Cooldown: 3 seconds."
      },
      {
        rarity: "purple",
        name: "Vocal",
        talent: "Vocal strums the guitar, emitting angry notes that have a 24%(+4% per ★↑) chance to silence enemies within 3 meters of their master for 6 seconds. Cooldown is 18 seconds."
      },
      {
        rarity: "purple",
        name: "Desert Wolf",
        talent: "Angrily howls at the enemy and intimidates them, decreasing the PVP Final Physical Damage Reduction and PVP Final Magic Damage Reduction of all enemies within 3 meters of their master by 12%(+2% per ★↑) each for 6 seconds. Cooldown is 18 seconds. This effect cannot stack."
      },
      {
        rarity: "purple",
        name: "Yoyo",
        talent: "Throws a stone at the enemy. Has a 24%(+4% per ★↑) chance to stun the target for 0.25 seconds. Cooldown is 3 seconds."
      },
      {
        rarity: "purple",
        name: "Side Winder",
        talent: "Tears savagely at the target, dealing 1200%(+200% per ★↑) Poison attribute Adaptive Damage and reducing the target's HP Regen by 24%(+4% per ★↑) (including HP Regen, HP Regen/5s, HP potion effects, and healing received) for 4s. 12-second cooldown."
      },
      {
        rarity: "purple",
        name: "Drainliar",
        talent: "Gives blood to their master, healing their master for 2.3%(+0.3% per ★↑) HP per second for 6 seconds. Cooldown is 24 seconds. This effect cannot stack."
      },
      {
        rarity: "purple",
        name: "Giearth",
        talent: "Speeds up mining efficiency by 46%(+6% per ★↑)."
      },
      {
        rarity: "purple",
        name: "Ghoul",
        talent: "Ghoul transforms the surrounding 3-meter area into dead land, dealing True Damage equal to 1.8%(+0.3% per ★↑) Max HP to enemies within range for 3s (does not apply to Boss monsters). 12-second cooldown."
      },
      {
        rarity: "purple",
        name: "Skeleton Worker",
        talent: "Awakens Muka's vengeful spirit. When they inflict enemies with debuffs, they ignore 24%(+4% per ★↑) of their Debuff Resistance and Duration Reduction (including specific resistances, Debuff Resistance, Debuff Duration Reduction, PVP Debuff Resistance, and PVP Debuff Duration Reduction)."
      },
      {
        rarity: "purple",
        name: "Myst",
        talent: "Grants a 42%(+3% per ★↑) chance of inflicting 1 stack of Poison on enemies within a 6-meter radius of the pet, lasting for 3s. 12-second cooldown."
      },
      {
        rarity: "purple",
        name: "Sasquatch",
        talent: "Grants an Ice Shield to its master for 5s, which inflicts 1 stack of Frost on each enemy attacker. Each stack of Frost reduces the target's Final Attack Speed by 24%(+6% per ★↑) and Final Haste by 2.4%(0.6% per ★↑) for 5s. Can inflict up to 1 stack on the same target per second. 15-second cooldown."
      },
      {
        rarity: "purple",
        name: "Golem",
        talent: "Grants Petrification to its master, increasing PvP Final Physical Damage Reduction and PvP Final Magic Damage Reduction by 12%(+2% per ★↑) for 6s. 18-second cooldown."
      },
      {
        rarity: "purple",
        name: "Marduk",
        talent: "Conjures a ring of fire to obstruct enemies from advancing, dealing 84%(14% per ★↑) of M.ATK Adaptive Fire Damage to enemies that attempt to pass the fire wall. Lasts for 10 seconds. The ring of fire can obstruct enemies up to 6(+1 per ★↑) times and will persist for at least 3 seconds. Cooldown: 12 seconds."
      },
      {
        rarity: "purple",
        name: "Verit",
        talent: "Reveals all stealth units within 8 meters of the master and marks them, increasing their damage received from the master by 16.01%(+2.67% per ★↑) for 9 seconds. Cooldown: 18 seconds."
      },
      {
        rarity: "purple",
        name: "Isis",
        talent: "Enables the master's normal attacks to ignore 48%(+8% per ★↑) of the target's defense. Lasts for 4 seconds. Cooldown: 12 seconds."
      },
      {
        rarity: "purple",
        name: "Zerom",
        talent: "Attacks the target, dealing 720%(+120% per ★↑) Adaptive Fire Damage. Cooldown: 6 seconds."
      },
      {
        rarity: "purple",
        name: "Anubis",
        talent: "Increases the master's body size by 20%, granting each of their melee normal attacks an additional 59(+10 per ★↑) x STR Adaptive Undead Damage and increasing their MSPD by 0.5, stacking up to 4 times. The effect lasts for 9 seconds and only occurs once every 18 seconds."
      },
      {
        rarity: "purple",
        name: "Munak",
        talent: "Conjures a Ring of the Dead under the master's feet, granting 36%(+6% per ★↑) Final P.DMG and M.DMG Bonus, and 24%(+4% per ★↑) Final P.DEF and Final M.DEF to the allies within a 4-meter radius for 6 seconds. Cooldown: 12 seconds."
      },
      {
        rarity: "purple",
        name: "Marc",
        talent: "Attacks the target, dealing 720%(+120% per ★↑) Adaptive Water Damage. Cooldown: 6 seconds."
      },
      {
        rarity: "purple",
        name: "Dokebi",
        talent: "Increases the master's Final ASPD by 160.01%(+26.67% per ★↑) and Crit DMG Bonus by 65%(+11% per ★↑) for 6 seconds. Cooldown: 12 seconds."
      },
      {
        rarity: "purple",
        name: "Sohee",
        talent: "Consumes 20% of the master's Max HP (unusable when the master's HP is low) to curse the targets within 4 meters of the master, increasing all their skill cooldowns by 4.01(+0.67 per ★↑) seconds and cast time by 1.01(+0.17 per ★↑) seconds. This effect lasts for 8 seconds and does not apply to MVP, MINI, and Bosses. Cooldown: 16 seconds."
      },
      {
        rarity: "purple",
        name: "Nine Tail",
        talent: "Charms the target, reducing their Final DMG Bonus by 31%(+5% per ★↑) while granting the master 31.9%(+5.3% per ★↑) increased damage against the target. This effect lasts for 6 seconds and does not apply to MVP, MINI, and Bosses. Cooldown: 24 seconds."
      },
      {
        rarity: "purple",
        name: "Eggyra",
        talent: "Sends the target's mind to roam among multiple parallel universes, inflicting a Psychosis status on them. If the affected target is a player, they will suffer Adaptive Ghost Damage equal to 1.79%(+0.3% per ★↑) of their Max HP each time they use a skill. If the affected target is a monster, however, it will take 377%(+63% per ★↑) Adaptive Ghost Damage every 0.5 seconds over 4 seconds. Cooldown: 20 seconds."
      },
      {
        rarity: "purple",
        name: "Ruyi Toad",
        talent: "Sprinkles osmanthus flowers over a 20-meter area, granting all allies the dual blessings of Osmanthus and Moonlight. While the Osmanthus effect is active, allies' Debuff Resistance is increased by 8.4(+2.8 per ★↑), and their MSPD is increased by 2. While the Moonlight effect is active, the carrier gains a shield equal to 7.8%(+2.6% per ★↑) of the Max HP. Osmanthus and Moonlight effects last for 5 seconds. Cooldown: 16 seconds."
      },
      {
        rarity: "gold",
        name: "Mastering",
        talent: "Jumps up high and flies fiercely downward at the target, dealing 576%(+72% per ★↑) Neutral damage of a type that matches their own to enemies within 3 meters and stuns all enemies for 2 seconds. Cooldown is 24 seconds."
      },
      {
        rarity: "gold",
        name: "Eclipse",
        talent: "Summons a Lunatic General, charging at all enemies within 5 meters of their master and dealing 576%(+72% per ★↑) Neutral damage of a type that matches their own. Has a 58%(+6% per ★↑) chance to make the target bleed for 6 seconds. Cooldown is 24 seconds."
      },
      {
        rarity: "gold",
        name: "Dragon Fly",
        talent: "Grants a 80%(+5% per ★↑) chance of your pet inflicting either Silence, Freeze, Bleed, Sleep, or Curse on enemies within a 9-meter range, lasting for 3s. 12-second cooldown."
      },
      {
        rarity: "gold",
        name: "Toad",
        talent: "Toad grants Poison Skin to its master for 4s, and inflicts 1 stack of Poison on any attacker, lasting for 4s. Can inflict up to 1 stack of Poison on the same target per second. 8-second cooldown."
      },
      {
        rarity: "gold",
        name: "Mistress",
        talent: "Shoots a poisonous needle at the enemy that has a 8%(+1% per ★↑) chance to directly kill the enemy. If the target is not killed, it instead deals Neutral damage of a type that matches their own equal to 8%(+1% per ★↑) of the target's Max HP. Cooldown is 24 seconds. Not effective against Bosses, MVPs, and Minis."
      },
      {
        rarity: "gold",
        name: "Ghostring",
        talent: "Ghostring rises into the air before plunging down into the ground, inflicting Ghost attribute Magic Damage equal to 640%(+80% per ★↑) Magic Attack on enemies within a 6-meter radius of its master and knocking back enemies by 3m. 12-second cooldown."
      },
      {
        rarity: "gold",
        name: "Phreeoni",
        talent: "Devours the target. If the target is a monster, it will be killed immediately. If the target is a player, deals Neutral Damage which is equal to 16%(+2% per ★↑) of the target's Max HP on it and spits it out after 5 seconds. Cooldown is 24 seconds. Not effective against Bosses, MVPs, and Minis. Devouring-type skills cannot be cast on the same target for 24 seconds."
      },
      {
        rarity: "gold",
        name: "Moonlight Flower",
        talent: "Clears all debuffs from its master, grants immunity to all debuffs for 3s (does not apply to certain Boss monster debuffs and debuffs that cannot be cleansed or are not affected by immunity), and recovers 16%(+2% per ★↑) Max HP per second. 12-second cooldown."
      },
      {
        rarity: "gold",
        name: "SD Colossal Titan",
        talent: "Every 24s, scorching steam is released into the surrounding area for 6s. Every 0.5s, the attack deals damage to all targets in range that is equal to the target's (Max HP (2.5%(+0.5% per ★↑) + 1%) + (25%(+5% per ★↑) + 15%)*Adaptive Attack Power) in Fire Stat Adaptive damage. (Not effective on MVP, Mini, and bosses.) Targets that have taken damage 4 consecutive times take fire damage that is increased by 50% for 10s."
      },
      {
        rarity: "gold",
        name: "Ramiris",
        talent: "Every second, restores 18%(+2% per ★↑) HP of all allied units within 4 meters and deals 400%(+50% per ★↑) Adaptive Neutral Damage to enemies within range. Lasts for 6 seconds. Cooldown: 24 seconds."
      },
      {
        rarity: "gold",
        name: "Golden Thief Bug",
        talent: "When damage taken by the master reaches 10% of their Max HP, it converts the master's skin into barbed armor, turning their armor attribute into Fire for 6 seconds. Within this period, each time the master takes damage, the attacker suffers 200%(+25% per ★↑) Adaptive Fire Damage. Cooldown: 24 seconds."
      },
      {
        rarity: "gold",
        name: "Drake",
        talent: "Launches a water ball at the target, dealing Adaptive Undead Damage equal to 8%(+1% per ★↑) of their Max HP and slowing them for 3 seconds. If the target is already slowed, the water ball has a 30%(+4% per ★↑) chance to imprison them (does not apply to MVP, MINI, and Bosses; party members can touch the water ball to remove the imprisonment), reducing the healing effects they receive by 100% and dealing True Damage equal to 12% of their Max HP every second for 10 seconds. This effect only occurs once every 30 seconds."
      },
      {
        rarity: "gold",
        name: "Osiris",
        talent: "Osiris touches the target, cursing them with a 8%(+1% per ★↑) chance [every 150(-10 per ★↑) VIT of the target increases the chance by an additional 1%, up to 80%; does not apply to MVP, MINI, and Bosses]. Cursed targets will have their Max HP decreased by 60% for 12 seconds. If the touch fails to inflict the curse, the target will suffer Adaptive Undead Damage equal to 9%(+1% per ★↑) of their Max HP. (This damage does not apply to MVP, MINI, and Bosses.) The effect only occurs once every 24 seconds."
      },
      {
        rarity: "gold",
        name: "Strouf",
        talent: "Randomly targets 3 enemy units and unleashes a 4-meter-radius Frost Mark at each of them. After a 1.5-second warning, deals 1200%(+150% per ★↑) Adaptive Water Damage respectively and freezes the targets for 3 seconds (does not apply to MVP, MINI, and Bosses). Cooldown: 24 seconds."
      },
      {
        rarity: "gold",
        name: "King Dramoh",
        talent: "Marks an enemy. After 5 seconds, deals 1600%(+200% per ★↑) Adaptive Water Damage to a 5-meter radius around the marked target's location. Cooldown: 24 seconds."
      },
      {
        rarity: "gold",
        name: "Kraken",
        talent: "Unleashes a pulsing beam from the eye, dealing 480%(+60% per ★↑) Adaptive Water Damage every 0.5 seconds to all targets ahead. For targets hit more than 3 times, each damage has a 34%(+4% per ★↑) chance to inflict one of the following states on them: Silence, Freeze, Bleed, Confuse, Curse, and Sleep (these effects do not apply to MVP, MINI, and Bosses) Duration: Debuffs last 3 seconds; the pulsing beam lasts 4 seconds. Cooldown: 24 seconds."
      },
      {
        rarity: "gold",
        name: "Pharaoh",
        talent: "Controls gravitational forces to drag all nearby enemies within a 5-meter radius toward the central area. After 1.5 seconds, the thunderstorm falls, dealing 2400%(+300% per ★↑) Adaptive Shadow Damage and increasing the hit targets' SP costs by 70%(+8% per ★↑) for 8 seconds when they use skills. Cooldown: 24 seconds."
      },
      {
        rarity: "gold",
        name: "Maya",
        talent: "When damage taken by the master reaches 10% of their Max HP, adds a Guard buff to the master that lasts 12 seconds. Within this period, the master becomes immune to 16(+2 per ★↑) ranged attacks; each time the immunity is triggered, the attacker will have their Final DMG Bonus decreased by 8.8%(+1.1% per ★↑) for 6 seconds, stacking up to 12 times. Cooldown: 24 seconds."
      },
      {
        rarity: "gold",
        name: "Orc Hero",
        talent: "Adds an Auto Counter buff to the master, increasing their Final DMG Reduction by 66.5%(+8.3% per ★↑) for 4 seconds. When the buff expires, deals 33%(+4% per ★↑) of the master's taken damage (before reduction) to all nearby targets. Cooldown: 20 seconds."
      },
      {
        rarity: "gold",
        name: "Puck",
        talent: "Puck begins with 6 stamina in the fully energized state. It can cast 1 ice spike every 3 seconds, consuming 1 stamina per spike, dealing Adaptive Fire DMG equal to 224%(+28% per star) of Adaptive ATK in total within a 4-meter radius. If there are 3 or fewer targets within range, the ice spike damage increases by 50%. Puck enters the fatigue state after casting 6 ice spikes in the fully energized state. In the fatigue state, if the master is attacked, Puck has a 6.25% chance to apply Drowsiness to the attacker 3 seconds later, lasting for 3 seconds. Drowsy Enemies can't move or attack, waking up after taking damage equal to 30% of their Max HP in total. In the fatigue state, Puck no longer casts ice spikes and recovers 1 stamina every 2 seconds. Once its stamina is back to 6, it re-enters the fully energized state and continues to cast ice spikes, dealing extra 20% damage to drowsy enemies affected by itself during its fatigue state."
      },
      {
        rarity: "gold",
        name: "Scarfed Alexander",
        talent: "The Fat Tiger ascends into the air before slamming into the ground, dealing 1540%(+230% per ★↑) Ghost or Neutral attribute DMG to targets within a 6-meter radius. This skill may trigger critical damage (based on the higher number of the master's Ghost or Neutral attributes, with damage shared by all targets within the area). It also boosts the master's Ghost and Neutral attributes by 18%(+3% per ★↑) for 6 seconds. There's a 35%(+5% per ★↑) chance to make the target bleeds for 6 seconds. Cooldown: 12 seconds. When Fat Tiger is casting Divine: Ghost Enhancement, if the master's Neutral Enhancement is greater than Ghost Enhancement, the effect will be changed to Neutral Enhancement."
      },
      {
        rarity: "gold",
        name: "Vesper",
        talent: "Deals Adaptive Neutral DMG and Holy attribute DMG equal to 2.2%(+0.2% per ★↑) of the target's Max HP within a 4-meter radius (up to 2 hits of 1000% of your ATK; critical hits possible). If the target is MVP, BOSS, or MINI, it deals Adaptive Holy DMG and Neutral attribute DMG equal to 470%(+70% per ★↑) (critical hits possible). Also grants a shield equal to 3.4%(+0.4% per ★↑) of Max HP multiplied by the number of critical hits dealt during the precious attacks for 6 seconds (up to 4 times). Cooldown: 12 seconds."
      }
    ];

    function renderPetTable(rarity='all'){
      const tbody=$("#petDatabaseTable tbody"); tbody.empty();
      const filtered = rarity==='all' ? petDatabase : petDatabase.filter(p=>p.rarity===rarity);
      if(filtered.length===0){
        tbody.append('<tr><td colspan="3" class="text-center text-secondary py-4">No pet data available.</td></tr>');
        return;
      }
      filtered.forEach(p=>{
        const badge =
          p.rarity==='gold' ? '<span class="badge text-bg-warning text-dark text-uppercase">gold</span>' :
          p.rarity==='purple' ? '<span class="badge text-bg-primary text-uppercase">purple</span>' :
          '<span class="badge text-bg-secondary text-uppercase">white</span>';
        tbody.append(`
          <tr>
            <td class="fw-semibold">${p.name}</td>
            <td>${badge}</td>
            <td>${p.talent}</td>
          </tr>
        `);
      });
    }
    $('a[data-bs-toggle="tab"][href="#pet-database"]').on('shown.bs.tab', function(){ renderPetTable(); });
    $('#filterRarity').on('change', function(){ renderPetTable(this.value); });

    // Auto-run on load
    $(function(){
      calculateExp();
      $('a[data-bs-toggle="tab"][href="#pet-exp-simulator"]').on('shown.bs.tab', calculateExp);
    });