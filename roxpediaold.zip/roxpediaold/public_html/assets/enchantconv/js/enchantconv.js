﻿const equipmentTypeSelect = document.getElementById('equipmentType');
const weaponTypeSelect = document.getElementById('weaponType');
const form = document.getElementById('enchantForm');
const resultDiv = document.getElementById('result');
const errorDiv = document.getElementById('formError');

let conversionMatrix = {};
let cityList = [];
let dataLoaded = false;

function getDataUrl() {
  const configured = window.ENCHANT_CONVERSION_DATA_URL;
  if (typeof configured === 'string' && configured.trim() !== '') {
    try {
      const resolved = new URL(configured, window.location.href);
      if (resolved.origin === window.location.origin) {
        return resolved.toString();
      }
    } catch (error) {
      // Fall back to relative URL below.
    }
  }

  try {
    const path = window.location.pathname.replace(/\/+$/, '');
    return `${window.location.origin}${path}/data`;
  } catch (error) {
    return '/enchantconversion/data';
  }
}

function getStartingSelect(index) {
  return document.getElementById(`startingCity${index}`);
}

function getTargetSelect(index) {
  return document.getElementById(`targetCity${index}`);
}

function setSelectOptions(selectEl, placeholder, selectedValue) {
  if (!selectEl) {
    return;
  }

  const options = [`<option value="">${placeholder}</option>`];
  cityList.forEach((city) => {
    options.push(`<option value="${city}">${city}</option>`);
  });

  selectEl.innerHTML = options.join('');

  if (selectedValue && cityList.includes(selectedValue)) {
    selectEl.value = selectedValue;
  }
}

function repopulateCitySelects() {
  for (let i = 1; i <= 3; i += 1) {
    const startSel = getStartingSelect(i);
    const targetSel = getTargetSelect(i);

    const currentStart = startSel ? startSel.value : '';
    const currentTarget = targetSel ? targetSel.value : '';

    setSelectOptions(startSel, 'Starting City', currentStart);
    setSelectOptions(targetSel, 'Target City', currentTarget);
  }

  updateTargetCityOptions();
}

function updateTargetCityOptions() {
  for (let i = 1; i <= 3; i += 1) {
    const startSel = getStartingSelect(i);
    const targetSel = getTargetSelect(i);

    if (!startSel || !targetSel) {
      continue;
    }

    const selectedStart = startSel.value;
    const selectedTarget = targetSel.value;

    targetSel.querySelectorAll('option').forEach((option) => {
      if (!option.value) {
        option.disabled = false;
        return;
      }
      option.disabled = option.value === selectedStart;
    });

    if (selectedTarget === selectedStart) {
      targetSel.value = '';
    }

    targetSel.disabled = !selectedStart;
  }
}

function clearError() {
  if (!errorDiv) {
    return;
  }
  errorDiv.style.display = 'none';
  errorDiv.innerHTML = '';
}

function showError(message) {
  if (!errorDiv) {
    return;
  }
  errorDiv.innerHTML = `<strong>Oops!</strong> ${message}`;
  errorDiv.style.display = 'block';
}

function getEquipmentKey(equipmentType, weaponType) {
  if (equipmentType === 'Weapon') {
    return weaponType ? `Weapon:${weaponType}` : null;
  }
  if (equipmentType === 'Armor') {
    return 'Armor';
  }
  if (equipmentType === 'Accessory') {
    return 'Accessory';
  }
  return null;
}

function getConversionRow(equipmentKey, startLevel, startCity, targetCity) {
  const bySource = conversionMatrix[startCity];
  if (!bySource) {
    return null;
  }

  const byEquip = bySource[equipmentKey];
  if (!byEquip) {
    return null;
  }

  const byLevel = byEquip[String(startLevel)];
  if (!byLevel) {
    return null;
  }

  return byLevel[targetCity] || null;
}

function normalizeCitiesFromResponse(payload) {
  if (Array.isArray(payload?.cities) && payload.cities.length > 0) {
    return payload.cities
      .map((city) => (city && typeof city.name === 'string' ? city.name : ''))
      .filter((name) => name !== '');
  }

  if (payload?.matrix && typeof payload.matrix === 'object') {
    return Object.keys(payload.matrix);
  }

  return [];
}

async function loadConversionData() {
  try {
    const response = await fetch(getDataUrl(), {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const payload = await response.json();

    if (!payload || payload.success !== true || typeof payload.matrix !== 'object') {
      throw new Error('Invalid conversion payload');
    }

    conversionMatrix = payload.matrix;
    cityList = normalizeCitiesFromResponse(payload);
    dataLoaded = true;

    repopulateCitySelects();
    clearError();
  } catch (error) {
    dataLoaded = false;
    conversionMatrix = {};
    cityList = [];
    showError('Failed to load dynamic enchant conversion data. Please refresh the page.');
    console.error('[EnchantConversion] Failed to load data:', error);
  }
}

for (let i = 1; i <= 3; i += 1) {
  const startSel = getStartingSelect(i);
  if (startSel) {
    startSel.addEventListener('change', updateTargetCityOptions);
  }
}

updateTargetCityOptions();
loadConversionData();

form?.addEventListener('submit', (event) => {
  event.preventDefault();

  const equipmentType = equipmentTypeSelect?.value || '';
  const weaponType = weaponTypeSelect?.value || '';

  if (!equipmentType || (equipmentType === 'Weapon' && !weaponType)) {
    return;
  }

  clearError();

  if (!dataLoaded) {
    showError('Conversion data is not ready yet. Please try again in a moment.');
    return;
  }

  const equipmentKey = getEquipmentKey(equipmentType, weaponType);
  if (!equipmentKey) {
    showError('Invalid equipment selection.');
    return;
  }

  const slots = [];
  for (let i = 1; i <= 3; i += 1) {
    const startCity = getStartingSelect(i)?.value || '';
    const targetCity = getTargetSelect(i)?.value || '';
    const levelRaw = document.getElementById(`startingLevel${i}`)?.value || '';
    const startLevel = Number.parseInt(levelRaw, 10);

    slots.push({
      startCity,
      targetCity,
      startLevel: Number.isNaN(startLevel) ? null : startLevel,
    });
  }

  const validSlots = slots.filter((slot) => slot.startCity && slot.targetCity && slot.startLevel);

  let html = '<h5>Calculation Result per Enchantment Slot:</h5>';
  if (equipmentType === 'Weapon') {
    html += `<p><strong>Equipment Type:</strong> Weapon (${weaponType})</p>`;
  } else {
    html += `<p><strong>Equipment Type:</strong> ${equipmentType}</p>`;
  }

  if (validSlots.length === 0) {
    html += '<p style="color:red;"><strong>Please fill at least one enchant slot completely to calculate.</strong></p>';
  } else {
    validSlots.forEach((slot) => {
      const conversion = getConversionRow(
        equipmentKey,
        slot.startLevel,
        slot.startCity,
        slot.targetCity,
      );

      if (!conversion) {
        html += `
          <div style="border:1px solid #ddd; padding:10px; margin-bottom:10px; border-radius:5px;">
            <h6>Transfer Enchantment from ${slot.startCity} -> ${slot.targetCity} | Level: ${slot.startLevel}</h6>
            <p><strong>No conversion data found</strong> for this route/equipment/level.</p>
          </div>
        `;
        return;
      }

      const effectiveLevel = Number.parseInt(conversion.effectiveLevel, 10) || 0;
      const townQty = Number.parseInt(conversion.townQty, 10) || 0;
      const aldeQty = Number.parseInt(conversion.aldebaranQty, 10) || 0;
      const stamina = (townQty + aldeQty) * 10;

      const townStoneName = conversion.townStoneName || `Item #${conversion.townStoneId || 0}`;
      const aldeStoneName = conversion.aldebaranStoneName || `Item #${conversion.aldebaranStoneId || 0}`;

      html += `
        <div style="border:1px solid #ddd; padding:10px; margin-bottom:10px; border-radius:5px;">
          <h6>Transfer Enchantment from ${slot.startCity} -> ${slot.targetCity} | Level: ${slot.startLevel} -> ${effectiveLevel} (effective)</h6>
          <p><strong>Stones Needed</strong>: ${townQty} ${townStoneName} (${slot.targetCity}) & ${aldeQty} ${aldeStoneName} (Aldebaran)</p>
          <p><strong>Stamina Consumption:</strong> ${stamina} stamina</p>
        </div>
      `;
    });
  }

  if (resultDiv) {
    resultDiv.innerHTML = html;
    resultDiv.style.display = 'block';
  }
});
