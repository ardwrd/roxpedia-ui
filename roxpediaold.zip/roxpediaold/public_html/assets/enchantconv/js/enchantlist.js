  const enchantDataByCity = {
    "Prontera": `
      <h5 class="mb-3">Prontera Enchantment (Weapon)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr>
            <th>Stat Name</th>
            <th>1H</th>
            <th>2H</th>
            <th>Dagger</th>
            <th>Shield</th>
          </tr>
        </thead>
        <tbody>
          <tr><td class="text-start">STR</td><td>4</td><td>6</td><td>3</td><td>2</td></tr>
          <tr><td class="text-start">AGI</td><td>4</td><td>6</td><td>3</td><td>2</td></tr>
          <tr><td class="text-start">VIT</td><td>4</td><td>6</td><td>3</td><td>2</td></tr>
          <tr><td class="text-start">INT</td><td>4</td><td>6</td><td>3</td><td>2</td></tr>
          <tr><td class="text-start">DEX</td><td>4</td><td>6</td><td>3</td><td>2</td></tr>
          <tr><td class="text-start">LUK</td><td>4</td><td>6</td><td>3</td><td>2</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Prontera Enchantment (Armor)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Armor</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">STR</td><td>2</td></tr>
          <tr><td class="text-start">AGI</td><td>2</td></tr>
          <tr><td class="text-start">VIT</td><td>2</td></tr>
          <tr><td class="text-start">INT</td><td>2</td></tr>
          <tr><td class="text-start">DEX</td><td>2</td></tr>
          <tr><td class="text-start">LUK</td><td>2</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Prontera Enchantment (Accessory)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Acc / Talis</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">STR</td><td>2</td></tr>
          <tr><td class="text-start">AGI</td><td>2</td></tr>
          <tr><td class="text-start">VIT</td><td>2</td></tr>
          <tr><td class="text-start">INT</td><td>2</td></tr>
          <tr><td class="text-start">DEX</td><td>2</td></tr>
          <tr><td class="text-start">LUK</td><td>2</td></tr>
        </tbody>
      </table>
    `,
    "Morroc": `
      <h5 class="mb-3">Morroc Enchantment (Weapon)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>1H</th><th>2H</th><th>Dagger</th><th>Shield</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">P.ATK</td><td>36</td><td>54</td><td>27</td><td>18</td></tr>
          <tr><td class="text-start">M.ATK</td><td>36</td><td>54</td><td>27</td><td>18</td></tr>
          <tr><td class="text-start">P.PEN</td><td>36</td><td>54</td><td>27</td><td>18</td></tr>
          <tr><td class="text-start">M.PEN</td><td>36</td><td>54</td><td>27</td><td>18</td></tr>
          <tr><td class="text-start">Crit DMG Bonus</td><td>2.40%</td><td>3.60%</td><td>1.80%</td><td>1.20%</td></tr>
          <tr><td class="text-start">P.DMG Bonus</td><td>108</td><td>162</td><td>81</td><td>54</td></tr>
          <tr><td class="text-start">M.DMG Bonus</td><td>108</td><td>162</td><td>81</td><td>54</td></tr>
          <tr><td class="text-start">P.DMG Bonus %</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">M.DMG Bonus %</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Morroc Enchantment (Armor)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Armor</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">DEF</td><td>18</td></tr>
          <tr><td class="text-start">MDEF</td><td>18</td></tr>
          <tr><td class="text-start">Max HP</td><td>1080</td></tr>
          <tr><td class="text-start">Max SP</td><td>90</td></tr>
          <tr><td class="text-start">P.DMG RED</td><td>54</td></tr>
          <tr><td class="text-start">M.DMG RED</td><td>54</td></tr>
          <tr><td class="text-start">P.DMG RED%</td><td>1.5%</td></tr>
          <tr><td class="text-start">M.DMG RED%</td><td>1.5%</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Morroc Enchantment (Accessory)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Acc / Talis</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">ASPD</td><td>18</td></tr>
          <tr><td class="text-start">Haste</td><td>18</td></tr>
          <tr><td class="text-start">Hit</td><td>18</td></tr>
          <tr><td class="text-start">Crit</td><td>18</td></tr>
          <tr><td class="text-start">Flee</td><td>18</td></tr>
          <tr><td class="text-start">Anti-Crit</td><td>18</td></tr>
          <tr><td class="text-start">Debuff RED</td><td>0.75</td></tr>
          <tr><td class="text-start">Debuff RES</td><td>0.75</td></tr>
          <tr><td class="text-start">Debuff PEN</td><td>0.75</td></tr>
          <tr><td class="text-start">Debuff Enhancement</td><td>0.75</td></tr>
        </tbody>
      </table>
    `,
    "Izlude": `
      <h5 class="mb-3">Izlude Enchantment (Weapon)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>1H</th><th>2H</th><th>Dagger</th><th>Shield</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">Bonus DMG to Angel</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Demon</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Formless</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Insect</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Fish</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Demi-Human</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Undead</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Dragon</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Plant</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Brute</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Izlude Enchantment (Armor)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Armor</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">Angel DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Demon DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Formless DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Insect DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Fish DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Demi-Human DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Undead DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Dragon DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Plant DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Brute DMG RED</td><td>1%</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Izlude Enchantment (Accessory)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Acc / Talis</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">Bonus DMG to Large</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Medium</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Small</td><td>1%</td></tr>
          <tr><td class="text-start">Neutral Enhance</td><td>1%</td></tr>
          <tr><td class="text-start">Fire Enhance</td><td>1%</td></tr>
          <tr><td class="text-start">Water Enhance</td><td>1%</td></tr>
          <tr><td class="text-start">Wind Enhance</td><td>1%</td></tr>
          <tr><td class="text-start">Earth Enhance</td><td>1%</td></tr>
          <tr><td class="text-start">Poison Enhance</td><td>1%</td></tr>
          <tr><td class="text-start">Holy Enhance</td><td>1%</td></tr>
          <tr><td class="text-start">Shadow Enhance</td><td>1%</td></tr>
          <tr><td class="text-start">Ghost Enhance</td><td>1%</td></tr>
          <tr><td class="text-start">Undead Enhance</td><td>1%</td></tr>
        </tbody>
      </table>
    `,
    "Alberta": `
      <h5 class="mb-3">Alberta Enchantment (Weapon)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>1H</th><th>2H</th><th>Dagger</th><th>Shield</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">Final P.DMG Bonus</td><td>1.60%</td><td>2.40%</td><td>1.20%</td><td>0.80%</td></tr>
          <tr><td class="text-start">Final M.DMG Bonus</td><td>1.60%</td><td>2.40%</td><td>1.20%</td><td>0.80%</td></tr>
          <tr><td class="text-start">Bonus DMG to Neutral</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Fire</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Water</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Wind</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Earth</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Poison</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Holy</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Shadow</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Ghost</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
          <tr><td class="text-start">Bonus DMG to Undead</td><td>2%</td><td>3%</td><td>1.5%</td><td>1%</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Alberta Enchantment (Armor)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Armor</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">Neutral DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Fire DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Water DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Wind DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Earth DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Poison DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Holy DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Shadow DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Ghost DMG RED</td><td>1%</td></tr>
          <tr><td class="text-start">Undead DMG RED</td><td>1%</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Alberta Enchantment (Accessory)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Acc / Talis</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">P.DEF%</td><td>1.6%</td></tr>
          <tr><td class="text-start">M.DEF%</td><td>1.6%</td></tr>
          <tr><td class="text-start">ASPD</td><td>1.6%</td></tr>
          <tr><td class="text-start">Haste</td><td>1.6%</td></tr>
          <tr><td class="text-start">Hit</td><td>1.6%</td></tr>
          <tr><td class="text-start">Dodge</td><td>1.6%</td></tr>
          <tr><td class="text-start">Crit</td><td>1.6%</td></tr>
          <tr><td class="text-start">Anti-Crit</td><td>1.6%</td></tr>
          <tr><td class="text-start">P.PEN</td><td>1.6%</td></tr>
          <tr><td class="text-start">M.PEN</td><td>1.6%</td></tr>
        </tbody>
      </table>
    `,
    "Payon": `
      <h5 class="mb-3">Payon Enchantment (Weapon)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>1H</th><th>2H</th><th>Dagger</th><th>Shield</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">STR</td><td>10</td><td>15</td><td>7.5</td><td>5</td></tr>
          <tr><td class="text-start">AGI</td><td>10</td><td>15</td><td>7.5</td><td>5</td></tr>
          <tr><td class="text-start">INT</td><td>10</td><td>15</td><td>7.5</td><td>5</td></tr>
          <tr><td class="text-start">DEX</td><td>10</td><td>15</td><td>7.5</td><td>5</td></tr>
          <tr><td class="text-start">VIT</td><td>10</td><td>15</td><td>7.5</td><td>5</td></tr>
          <tr><td class="text-start">LUK</td><td>10</td><td>15</td><td>7.5</td><td>5</td></tr>
          <tr><td class="text-start">P.ATK</td><td>60</td><td>90</td><td>45</td><td>30</td></tr>
          <tr><td class="text-start">M.ATK</td><td>60</td><td>90</td><td>45</td><td>30</td></tr>
          <tr><td class="text-start">P.PEN</td><td>60</td><td>90</td><td>45</td><td>30</td></tr>
          <tr><td class="text-start">M.PEN</td><td>60</td><td>90</td><td>45</td><td>30</td></tr>
          <tr><td class="text-start">Crit DMG Bonus</td><td>3.60%</td><td>5.40%</td><td>2.70%</td><td>1.80%</td></tr>
          <tr><td class="text-start">P.DMG Bonus</td><td>240</td><td>360</td><td>180</td><td>120</td></tr>
          <tr><td class="text-start">M.DMG Bonus</td><td>240</td><td>360</td><td>180</td><td>120</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Payon Enchantment (Armor)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Armor</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">STR</td><td>5</td></tr>
          <tr><td class="text-start">VIT</td><td>5</td></tr>
          <tr><td class="text-start">LUK</td><td>5</td></tr>
          <tr><td class="text-start">AGI</td><td>5</td></tr>
          <tr><td class="text-start">DEX</td><td>5</td></tr>
          <tr><td class="text-start">P.DEF</td><td>30</td></tr>
          <tr><td class="text-start">M.DEF</td><td>30</td></tr>
          <tr><td class="text-start">Max HP</td><td>2400</td></tr>
          <tr><td class="text-start">Max SP</td><td>150</td></tr>
          <tr><td class="text-start">P.DMG RED</td><td>120</td></tr>
          <tr><td class="text-start">M.DMG RED</td><td>120</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Payon Enchantment (Accessory)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Acc / Talis</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">AGI</td><td>5</td></tr>
          <tr><td class="text-start">VIT</td><td>5</td></tr>
          <tr><td class="text-start">DEX</td><td>5</td></tr>
          <tr><td class="text-start">STR</td><td>5</td></tr>
          <tr><td class="text-start">INT</td><td>5</td></tr>
          <tr><td class="text-start">ASPD</td><td>30</td></tr>
          <tr><td class="text-start">Haste</td><td>30</td></tr>
          <tr><td class="text-start">Hit</td><td>30</td></tr>
          <tr><td class="text-start">Crit</td><td>30</td></tr>
          <tr><td class="text-start">Flee</td><td>30</td></tr>
          <tr><td class="text-start">Anti-Crit</td><td>30</td></tr>
        </tbody>
      </table>
    `,
    "Geffen": `
      <h5 class="mb-3">Geffen Enchantment (Weapon)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th class="text-start">Stat Name</th><th>1H</th><th>2H</th><th>Dagger</th><th>Shield</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">P.ATK%</td><td>2.4%</td><td>3.6%</td><td>1.8%</td><td>1.2%</td></tr>
          <tr><td class="text-start">M.ATK%</td><td>2.4%</td><td>3.6%</td><td>1.8%</td><td>1.2%</td></tr>
          <tr><td class="text-start">Final P.PEN</td><td>2.4%</td><td>3.6%</td><td>1.8%</td><td>1.2%</td></tr>
          <tr><td class="text-start">Final M.PEN</td><td>2.4%</td><td>3.6%</td><td>1.8%</td><td>1.2%</td></tr>
          <tr><td class="text-start">Final P.DMG Bonus</td><td>2.4%</td><td>3.6%</td><td>1.8%</td><td>1.2%</td></tr>
          <tr><td class="text-start">Final M.DMG Bonus</td><td>2.4%</td><td>3.6%</td><td>1.8%</td><td>1.2%</td></tr>
          <tr><td class="text-start">Crit DMG Bonus</td><td>4.8%</td><td>7.2%</td><td>3.6%</td><td>2.4%</td></tr>
          <tr><td class="text-start">Bonus Heal</td><td>2.4%</td><td>3.6%</td><td>1.8%</td><td>1.2%</td></tr>
          <tr><td class="text-start">P.Lifesteal</td><td>2.4%</td><td>3.6%</td><td>1.8%</td><td>1.2%</td></tr>
          <tr><td class="text-start">M.Lifesteal</td><td>2.4%</td><td>3.6%</td><td>1.8%</td><td>1.2%</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Geffen Enchantment (Armor)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th class="text-start">Stat Name</th><th>Armor</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">Max HP%</td><td>2.4%</td></tr>
          <tr><td class="text-start">Max SP%</td><td>2.4%</td></tr>
          <tr><td class="text-start">Bonus Heal Received</td><td>1.2%</td></tr>
          <tr><td class="text-start">Final P.DMG RED</td><td>1.2%</td></tr>
          <tr><td class="text-start">Final M.DMG RED</td><td>1.2%</td></tr>
          <tr><td class="text-start">Final P.DEF</td><td>1.2%</td></tr>
          <tr><td class="text-start">Final M.DEF</td><td>1.2%</td></tr>
          <tr><td class="text-start">Crit DMG RED</td><td>2.4%</td></tr>
          <tr><td class="text-start">HP Regen / 5 sec</td><td>0.6%</td></tr>
          <tr><td class="text-start">SP Regen / 5 sec</td><td>0.6%</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Geffen Enchantment (Accessory)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th class="text-start">Stat Name</th><th>Acc / Talis</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">Final ASPD</td><td>6%</td></tr>
          <tr><td class="text-start">Final Haste</td><td>0.6%</td></tr>
          <tr><td class="text-start">Final Crit</td><td>1.2%</td></tr>
          <tr><td class="text-start">Crit DMG Bonus</td><td>2.40%</td></tr>
          <tr><td class="text-start">Final Anti-Crit</td><td>1.2%</td></tr>
          <tr><td class="text-start">Final Flee</td><td>1.2%</td></tr>
          <tr><td class="text-start">Final Hit</td><td>1.2%</td></tr>
          <tr><td class="text-start">P.DMG REF</td><td>1.2%</td></tr>
          <tr><td class="text-start">M.DMG REF</td><td>1.2%</td></tr>
          <tr><td class="text-start">Debuff RED</td><td>1.5</td></tr>
          <tr><td class="text-start">Debuff RES</td><td>1.5</td></tr>
          <tr><td class="text-start">Debuff PEN</td><td>1.5</td></tr>
          <tr><td class="text-start">Debuff Enhancement</td><td>1.5</td></tr>
          <!-- NEW (2 Sep 2025) -->
          <tr><td class="text-start">Final P.PEN</td><td>1.2%</td></tr>
          <tr><td class="text-start">Final M.PEN</td><td>1.2%</td></tr>
        </tbody>
      </table>
      `,    
      "Glast Heim": `
        <h5 class="mb-3">Glast Heim Enchantment (Weapon)</h5>
        <table class="table table-sm table-bordered text-center">
          <thead class="table-secondary">
            <tr><th>Stat Name</th><th>1H</th><th>2H</th><th>Dagger</th><th>Shield</th></tr>
          </thead>
          <tbody>
            <tr><td class="text-start">STR%</td><td>1.12%</td><td>1.68%</td><td>0.84%</td><td>0.56%</td></tr>
            <tr><td class="text-start">AGI%</td><td>1.12%</td><td>1.68%</td><td>0.84%</td><td>0.56%</td></tr>
            <tr><td class="text-start">VIT%</td><td>1.12%</td><td>1.68%</td><td>0.84%</td><td>0.56%</td></tr>
            <tr><td class="text-start">INT%</td><td>1.12%</td><td>1.68%</td><td>0.84%</td><td>0.56%</td></tr>
            <tr><td class="text-start">DEX%</td><td>1.12%</td><td>1.68%</td><td>0.84%</td><td>0.56%</td></tr>
            <tr><td class="text-start">LUK%</td><td>1.12%</td><td>1.68%</td><td>0.84%</td><td>0.56%</td></tr>
            <tr><td class="text-start">PVP P.DMG Bonus</td><td>84</td><td>126</td><td>63</td><td>42</td></tr>
            <tr><td class="text-start">PVP M.DMG Bonus</td><td>84</td><td>126</td><td>63</td><td>42</td></tr>
            <tr><td class="text-start">PVP Final P.DMG Bonus</td><td>1.40%</td><td>2.10%</td><td>1.05%</td><td>0.70%</td></tr>
            <tr><td class="text-start">PVP Final M.DMG Bonus</td><td>1.40%</td><td>2.10%</td><td>1.05%</td><td>0.70%</td></tr>
            <tr><td class="text-start">P.DMG Bonus%</td><td>4.66%</td><td>6.99%</td><td>3.49%</td><td>2.33%</td></tr>
            <tr><td class="text-start">M.DMG Bonus%</td><td>4.66%</td><td>6.99%</td><td>3.49%</td><td>2.33%</td></tr>
          </tbody>
        </table>

        <h5 class="mb-3 mt-4">Glast Heim Enchantment (Armor)</h5>
        <table class="table table-sm table-bordered text-center">
          <thead class="table-secondary">
            <tr><th>Stat Name</th><th>Armor</th></tr>
          </thead>
          <tbody>
            <tr><td class="text-start">STR%</td><td>0.56%</td></tr>
            <tr><td class="text-start">AGI%</td><td>0.56%</td></tr>
            <tr><td class="text-start">VIT%</td><td>0.56%</td></tr>
            <tr><td class="text-start">INT%</td><td>0.56%</td></tr>
            <tr><td class="text-start">DEX%</td><td>0.56%</td></tr>
            <tr><td class="text-start">LUK%</td><td>0.56%</td></tr>
            <tr><td class="text-start">PVP P.DMG RED</td><td>42</td></tr>
            <tr><td class="text-start">PVP M.DMG RED</td><td>42</td></tr>
            <tr><td class="text-start">PVP Final P.DMG RED</td><td>0.7%</td></tr>
            <tr><td class="text-start">PVP Final M.DMG RED</td><td>0.7%</td></tr>
            <tr><td class="text-start">P.DMG RED%</td><td>3.5%</td></tr>
            <tr><td class="text-start">M.DMG RED%</td><td>3.5%</td></tr>
          </tbody>
        </table>

        <h5 class="mb-3 mt-4">Glast Heim Enchantment (Accessory)</h5>
        <table class="table table-sm table-bordered text-center">
          <thead class="table-secondary">
            <tr><th>Stat Name</th><th>Acc / Talis</th></tr>
          </thead>
          <tbody>
            <tr><td class="text-start">PVP P.DMG RED</td><td>42</td></tr>
            <tr><td class="text-start">PVP M.DMG RED</td><td>42</td></tr>
            <tr><td class="text-start">PVP Final P.DMG RED</td><td>0.7%</td></tr>
            <tr><td class="text-start">PVP Final M.DMG RED</td><td>0.7%</td></tr>
            <tr><td class="text-start">PVP Debuff RED</td><td>0.7</td></tr>
            <tr><td class="text-start">PVP Debuff RES</td><td>0.7</td></tr>
            <tr><td class="text-start">PVP P.DMG Bonus</td><td>42</td></tr>
            <tr><td class="text-start">PVP M.DMG Bonus</td><td>42</td></tr>
            <tr><td class="text-start">PVP Final P.DMG Bonus</td><td>0.7%</td></tr>
            <tr><td class="text-start">PVP Final M.DMG Bonus</td><td>0.7%</td></tr>
            <tr><td class="text-start">PVP Debuff PEN</td><td>0.7</td></tr>
            <tr><td class="text-start">PVP Debuff Enhancement</td><td>0.7</td></tr>
          </tbody>
        </table>
      `,
      "Comodo": `
        <h5 class="mb-3">Comodo Enchantment (Weapon)</h5>
        <table class="table table-sm table-bordered text-center">
          <thead class="table-secondary">
            <tr><th>Stat Name</th><th>1H</th><th>2H</th><th>Dagger</th><th>Shield</th></tr>
          </thead>
          <tbody>
            <tr><td class="text-start">STR</td><td>16</td><td>24</td><td>12</td><td>8</td></tr>
            <tr><td class="text-start">AGI</td><td>16</td><td>24</td><td>12</td><td>8</td></tr>
            <tr><td class="text-start">INT</td><td>16</td><td>24</td><td>12</td><td>8</td></tr>
            <tr><td class="text-start">DEX</td><td>16</td><td>24</td><td>12</td><td>8</td></tr>
            <tr><td class="text-start">Crit DMG Bonus</td><td>6.40%</td><td>9.60%</td><td>4.80%</td><td>3.20%</td></tr>
            <tr><td class="text-start">Final P.DMG Bonus</td><td>3.20%</td><td>4.80%</td><td>2.40%</td><td>1.60%</td></tr>
            <tr><td class="text-start">Final M.DMG Bonus</td><td>3.20%</td><td>4.80%</td><td>2.40%</td><td>1.60%</td></tr>
            <tr><td class="text-start">Final P.PEN</td><td>3.20%</td><td>4.80%</td><td>2.40%</td><td>1.60%</td></tr>
            <tr><td class="text-start">Final M.PEN</td><td>3.20%</td><td>4.80%</td><td>2.40%</td><td>1.60%</td></tr>
            <tr><td class="text-start">PVP P.DMG Bonus</td><td>96</td><td>144</td><td>72</td><td>48</td></tr>
            <tr><td class="text-start">PVP M.DMG Bonus</td><td>96</td><td>144</td><td>72</td><td>48</td></tr>
            <tr><td class="text-start">PVP Final P.DMG Bonus</td><td>1.60%</td><td>2.40%</td><td>1.20%</td><td>0.80%</td></tr>
            <tr><td class="text-start">PVP Final M.DMG Bonus</td><td>1.60%</td><td>2.40%</td><td>1.20%</td><td>0.80%</td></tr>
          </tbody>
        </table>

        <h5 class="mb-3 mt-4">Comodo Enchantment (Armor)</h5>
        <table class="table table-sm table-bordered text-center">
          <thead class="table-secondary">
            <tr><th>Stat Name</th><th>Armor</th></tr>
          </thead>
          <tbody>
            <tr><td class="text-start">STR</td><td>8</td></tr>
            <tr><td class="text-start">AGI</td><td>8</td></tr>
            <tr><td class="text-start">VIT</td><td>8</td></tr>
            <tr><td class="text-start">INT</td><td>8</td></tr>
            <tr><td class="text-start">DEX</td><td>8</td></tr>
            <tr><td class="text-start">LUK</td><td>8</td></tr>
            <tr><td class="text-start">Final P.DEF</td><td>1.6%</td></tr>
            <tr><td class="text-start">Final M.DEF</td><td>1.6%</td></tr>
            <tr><td class="text-start">PVP P.DMG RED</td><td>48</td></tr>
            <tr><td class="text-start">PVP M.DMG RED</td><td>48</td></tr>
            <tr><td class="text-start">PVP Final P.DMG RED</td><td>1.2%</td></tr>
            <tr><td class="text-start">PVP Final M.DMG RED</td><td>1.2%</td></tr>
          </tbody>
        </table>

        <h5 class="mb-3 mt-4">Comodo Enchantment (Accessory)</h5>
        <table class="table table-sm table-bordered text-center">
          <thead class="table-secondary">
            <tr><th>Stat Name</th><th>Acc / Talis</th></tr>
          </thead>
          <tbody>
            <tr><td class="text-start">Neutral Enhance</td><td>2%</td></tr>
            <tr><td class="text-start">Fire Enhance</td><td>2%</td></tr>
            <tr><td class="text-start">Water Enhance</td><td>2%</td></tr>
            <tr><td class="text-start">Wind Enhance</td><td>2%</td></tr>
            <tr><td class="text-start">Earth Enhance</td><td>2%</td></tr>
            <tr><td class="text-start">Poison Enhance</td><td>2%</td></tr>
            <tr><td class="text-start">Holy Enhance</td><td>2%</td></tr>
            <tr><td class="text-start">Shadow Enhance</td><td>2%</td></tr>
            <tr><td class="text-start">Ghost Enhance</td><td>2%</td></tr>
            <tr><td class="text-start">Undead Enhance</td><td>2%</td></tr>
            <tr><td class="text-start">PVP P.DMG RED</td><td>48</td></tr>
            <tr><td class="text-start">PVP M.DMG RED</td><td>48</td></tr>
            <tr><td class="text-start">PVP Final P.DMG RED</td><td>1.2%</td></tr>
            <tr><td class="text-start">PVP Final M.DMG RED</td><td>1.2%</td></tr>
            <tr><td class="text-start">PVP P.DMG Bonus</td><td>48</td></tr>
            <tr><td class="text-start">PVP M.DMG Bonus</td><td>48</td></tr>
            <tr><td class="text-start">PVP Final P.DMG Bonus</td><td>0.8%</td></tr>
            <tr><td class="text-start">PVP Final M.DMG Bonus</td><td>0.8%</td></tr>
          </tbody>
        </table>
      `,
      "Umbala": `
        <h5 class="mb-3">Umbala Enchantment (Weapon)</h5>
        <table class="table table-sm table-bordered text-center">
          <thead class="table-secondary">
            <tr><th>Stat Name</th><th>1H</th><th>2H</th><th>Dagger</th><th>Shield</th></tr>
          </thead>
          <tbody>
            <tr><td class="text-start">Crit DMG Bonus</td><td>6.4%</td><td>9.6%</td><td>4.8%</td><td>3.2%</td></tr>
            <tr><td class="text-start">Final P.DMG Bonus</td><td>3.2%</td><td>4.8%</td><td>2.4%</td><td>1.6%</td></tr>
            <tr><td class="text-start">Final M.DMG Bonus</td><td>3.2%</td><td>4.8%</td><td>2.4%</td><td>1.6%</td></tr>
            <tr><td class="text-start">P.DMG Bonus</td><td>672</td><td>1008</td><td>504</td><td>336</td></tr>
            <tr><td class="text-start">M.DMG Bonus</td><td>672</td><td>1008</td><td>504</td><td>336</td></tr>
            <tr><td class="text-start">Final P.PEN</td><td>3.2%</td><td>4.8%</td><td>2.4%</td><td>1.6%</td></tr>
            <tr><td class="text-start">Final M.PEN</td><td>3.2%</td><td>4.8%</td><td>2.4%</td><td>1.6%</td></tr>
          </tbody>
        </table>

        <h5 class="mb-3 mt-4">Umbala Enchantment (Armor)</h5>
        <table class="table table-sm table-bordered text-center">
          <thead class="table-secondary">
            <tr><th>Stat Name</th><th>Armor</th></tr>
          </thead>
          <tbody>
            <tr><td class="text-start">Final P.DMG RED</td><td>1.6%</td></tr>
            <tr><td class="text-start">Final M.DMG RED</td><td>1.6%</td></tr>
            <tr><td class="text-start">Final Anti-Crit</td><td>1.6%</td></tr>
            <tr><td class="text-start">Final Hit</td><td>1.6%</td></tr>
            <tr><td class="text-start">P.DMG RED</td><td>240</td></tr>
            <tr><td class="text-start">M.DMG RED</td><td>240</td></tr>
            <tr><td class="text-start">Final P.DEF</td><td>1.6%</td></tr>
            <tr><td class="text-start">Final M.DEF</td><td>1.6%</td></tr>
            <tr><td class="text-start">PVP Debuff RED</td><td>0.8</td></tr>
            <tr><td class="text-start">PVP Debuff RES</td><td>0.8</td></tr>
          </tbody>
        </table>

        <h5 class="mb-3 mt-4">Umbala Enchantment (Accessory)</h5>
        <table class="table table-sm table-bordered text-center">
          <thead class="table-secondary">
            <tr><th>Stat Name</th><th>Acc / Talis</th></tr>
          </thead>
          <tbody>
            <tr><td class="text-start">Final Crit</td><td>1.8%</td></tr>
            <tr><td class="text-start">Final Hit</td><td>1.8%</td></tr>
            <tr><td class="text-start">Crit DMG Bonus</td><td>3.60%</td></tr>
            <tr><td class="text-start">Final P.PEN</td><td>1.80%</td></tr>
            <tr><td class="text-start">Final M.PEN</td><td>1.80%</td></tr>
            <tr><td class="text-start">Bonus DMG to Large</td><td>2%</td></tr>
            <tr><td class="text-start">Bonus DMG to Medium</td><td>2%</td></tr>
            <tr><td class="text-start">Bonus DMG to Small</td><td>2%</td></tr>
            <tr><td class="text-start">Bonus DMG to Angel</td><td>2%</td></tr>
            <tr><td class="text-start">Bonus DMG to Demon</td><td>2%</td></tr>
            <tr><td class="text-start">Bonus DMG to Formless</td><td>2%</td></tr>
            <tr><td class="text-start">Bonus DMG to Insect</td><td>2%</td></tr>
            <tr><td class="text-start">Bonus DMG to Fish</td><td>2%</td></tr>
            <tr><td class="text-start">Bonus DMG to Demi-Human</td><td>2%</td></tr>
            <tr><td class="text-start">Bonus DMG to Undead</td><td>2%</td></tr>
            <tr><td class="text-start">Bonus DMG to Brute</td><td>2%</td></tr>
          </tbody>
        </table>
      `,
    "Juno": `
      <h5 class="mb-3">Juno Enchantment (Weapon)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>1H</th><th>2H</th><th>Dagger</th><th>Shield</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">PVP P.DMG Bonus</td><td>108</td><td>162</td><td>81</td><td>54</td></tr>
          <tr><td class="text-start">PVP M.DMG Bonus</td><td>108</td><td>162</td><td>81</td><td>54</td></tr>
          <tr><td class="text-start">PVP Final P.DMG Bonus</td><td>1.80%</td><td>2.70%</td><td>1.35%</td><td>0.90%</td></tr>
          <tr><td class="text-start">PVP Final M.DMG Bonus</td><td>1.80%</td><td>2.70%</td><td>1.35%</td><td>0.90%</td></tr>
          <tr><td class="text-start">P.DMG Bonus%</td><td>6%</td><td>9%</td><td>4.50%</td><td>3%</td></tr>
          <tr><td class="text-start">M.DMG Bonus%</td><td>6%</td><td>9%</td><td>4.50%</td><td>3%</td></tr>
          <tr><td class="text-start">PVP Debuff PEN</td><td>1.8</td><td>2.7</td><td>1.35%</td><td>0.9</td></tr>
          <tr><td class="text-start">PVP Debuff Enhancement</td><td>1.8</td><td>2.7</td><td>1.35%</td><td>0.9</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Juno Enchantment (Armor)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Armor</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">Final P.DMG RED</td><td>1.80%</td></tr>
          <tr><td class="text-start">Final M.DMG RED</td><td>1.80%</td></tr>
          <tr><td class="text-start">Final Anti-Crit</td><td>1.80%</td></tr>
          <tr><td class="text-start">Final Hit</td><td>1.80%</td></tr>
          <tr><td class="text-start">Final P.DEF</td><td>1.80%</td></tr>
          <tr><td class="text-start">Final M.DEF</td><td>1.80%</td></tr>
          <tr><td class="text-start">PVP Final P.DMG RED</td><td>1.35%</td></tr>
          <tr><td class="text-start">PVP Final M.DMG RED</td><td>1.35%</td></tr>
          <tr><td class="text-start">PVP Debuff RED</td><td>0.9</td></tr>
          <tr><td class="text-start">PVP Debuff RES</td><td>0.9</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Juno Enchantment (Accessory)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Acc / Talis</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">Neutral RES</td><td>6.75%</td></tr>
          <tr><td class="text-start">Fire RES</td><td>6.75%</td></tr>
          <tr><td class="text-start">Water RES</td><td>6.75%</td></tr>
          <tr><td class="text-start">Wind RES</td><td>6.75%</td></tr>
          <tr><td class="text-start">Earth RES</td><td>6.75%</td></tr>
          <tr><td class="text-start">Poison RES</td><td>6.75%</td></tr>
          <tr><td class="text-start">Holy RES</td><td>6.75%</td></tr>
          <tr><td class="text-start">Shadow RES</td><td>6.75%</td></tr>
          <tr><td class="text-start">Ghost RES</td><td>6.75%</td></tr>
          <tr><td class="text-start">Undead RES</td><td>6.75%</td></tr>
          <tr><td class="text-start">PVP Debuff RED</td><td>0.9</td></tr>
          <tr><td class="text-start">PVP Debuff RES</td><td>0.9</td></tr>
          <tr><td class="text-start">PVP Debuff PEN</td><td>0.9</td></tr>
          <tr><td class="text-start">PVP Debuff Enhancement</td><td>0.9</td></tr>
        </tbody>
      </table>
    `,
    "Einbroch": `
      <h5 class="mb-3">Einbroch Enchantment (Weapon)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>1H</th><th>2H</th><th>Dagger</th><th>Shield</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">Physical Lifesteal</td><td>1.2%</td><td>1.8%</td><td>0.9%</td><td>0.6%</td></tr>
          <tr><td class="text-start">Magic Lifesteal</td><td>1.2%</td><td>1.8%</td><td>0.9%</td><td>0.6%</td></tr>
          <tr><td class="text-start">PVP P.DMG Bonus</td><td>36</td><td>54</td><td>27</td><td>18</td></tr>
          <tr><td class="text-start">PVP M.DMG Bonus</td><td>36</td><td>54</td><td>27</td><td>18</td></tr>
          <tr><td class="text-start">PVP Final P.DMG Bonus</td><td>0.60%</td><td>0.90%</td><td>0.45%</td><td>0.30%</td></tr>
          <tr><td class="text-start">PVP Final M.DMG Bonus</td><td>0.60%</td><td>0.90%</td><td>0.45%</td><td>0.30%</td></tr>
          <tr><td class="text-start">PVP Debuff PEN</td><td>0.6%</td><td>0.9%</td><td>0.45%</td><td>0.3%</td></tr>
          <tr><td class="text-start">PVP Debuff Enhancement</td><td>0.6%</td><td>0.9%</td><td>0.45%</td><td>0.3%</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Einbroch Enchantment (Armor)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Armor</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">Max HP%</td><td>1.20%</td></tr>
          <tr><td class="text-start">Max SP%</td><td>1.20%</td></tr>
          <tr><td class="text-start">Final P.DEF</td><td>0.6%</td></tr>
          <tr><td class="text-start">Final M.DEF</td><td>0.6%</td></tr>
          <tr><td class="text-start">Crit DMG RED</td><td>1.20%</td></tr>
          <tr><td class="text-start">PVP P.DMG RED</td><td>18</td></tr>
          <tr><td class="text-start">PVP M.DMG RED</td><td>18</td></tr>
          <tr><td class="text-start">PVP Final P.DMG RED</td><td>0.45%</td></tr>
          <tr><td class="text-start">PVP Final M.DMG RED</td><td>0.45%</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Einbroch Enchantment (Accessory)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Acc / Talis</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">P.DMG Reflection</td><td>0.6%</td></tr>
          <tr><td class="text-start">M.DMG Reflection</td><td>0.6%</td></tr>
          <tr><td class="text-start">PVP Final P.DMG RED</td><td>0.45%</td></tr>
          <tr><td class="text-start">PVP Final M.DMG RED</td><td>0.45%</td></tr>
          <tr><td class="text-start">PVP Debuff RED</td><td>0.3%</td></tr>
          <tr><td class="text-start">PVP Debuff RES</td><td>0.3%</td></tr>
          <tr><td class="text-start">PVP Final P.DMG Bonus</td><td>0.3%</td></tr>
          <tr><td class="text-start">PVP Final M.DMG Bonus</td><td>0.3%</td></tr>
        </tbody>
      </table>
    `,    
    "Rachel": `
      <h5 class="mb-3">Rachel Enchantment (Weapon)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>1H</th><th>2H</th><th>Dagger</th><th>Shield</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">Final P.DMG Bonus</td><td>4.4%</td><td>6.6%</td><td>3.3%</td><td>2.2%</td></tr>
          <tr><td class="text-start">Final M.DMG Bonus</td><td>4.4%</td><td>6.6%</td><td>3.3%</td><td>2.2%</td></tr>
          <tr><td class="text-start">Crit DMG Bonus</td><td>8.8%</td><td>13.2%</td><td>6.6%</td><td>4.4%</td></tr>
          <tr><td class="text-start">Final P.PEN</td><td>4.4%</td><td>6.6%</td><td>3.3%</td><td>2.2%</td></tr>
          <tr><td class="text-start">Final M.PEN</td><td>4.4%</td><td>6.6%</td><td>3.3%</td><td>2.2%</td></tr>
          <tr><td class="text-start">P.ATK</td><td>4.4%</td><td>6.6%</td><td>3.3%</td><td>2.2%</td></tr>
          <tr><td class="text-start">M.ATK</td><td>4.4%</td><td>6.6%</td><td>3.3%</td><td>2.2%</td></tr>
          <tr><td class="text-start">P.Lifesteal</td><td>4.4%</td><td>6.6%</td><td>3.3%</td><td>2.2%</td></tr>
          <tr><td class="text-start">M.Lifesteal</td><td>4.4%</td><td>6.6%</td><td>3.3%</td><td>2.2%</td></tr>
          <tr><td class="text-start">P.DMG Bonus</td><td>1188</td><td>1782</td><td>891</td><td>594</td></tr>
          <tr><td class="text-start">M.DMG Bonus</td><td>1188</td><td>1782</td><td>891</td><td>594</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Rachel Enchantment (Armor)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Armor</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">STR</td><td>11</td></tr>
          <tr><td class="text-start">AGI</td><td>11</td></tr>
          <tr><td class="text-start">VIT</td><td>11</td></tr>
          <tr><td class="text-start">INT</td><td>11</td></tr>
          <tr><td class="text-start">DEX</td><td>11</td></tr>
          <tr><td class="text-start">LUK</td><td>11</td></tr>
          <tr><td class="text-start">STR%</td><td>0.90%</td></tr>
          <tr><td class="text-start">AGI%</td><td>0.90%</td></tr>
          <tr><td class="text-start">VIT%</td><td>0.90%</td></tr>
          <tr><td class="text-start">INT%</td><td>0.90%</td></tr>
          <tr><td class="text-start">DEX%</td><td>0.90%</td></tr>
          <tr><td class="text-start">LUK%</td><td>0.90%</td></tr>
        </tbody>
      </table>

      <h5 class="mb-3 mt-4">Rachel Enchantment (Accessory)</h5>
      <table class="table table-sm table-bordered text-center">
        <thead class="table-secondary">
          <tr><th>Stat Name</th><th>Acc / Talis</th></tr>
        </thead>
        <tbody>
          <tr><td class="text-start">PVP Final P.DMG Bonus</td><td>2.2%</td></tr>
          <tr><td class="text-start">PVP Final M.DMG Bonus</td><td>2.2%</td></tr>
          <tr><td class="text-start">Neutral Enhance</td><td>2.75%</td></tr>
          <tr><td class="text-start">Fire Enhance</td><td>2.75%</td></tr>
          <tr><td class="text-start">Water Enhance</td><td>2.75%</td></tr>
          <tr><td class="text-start">Wind Enhance</td><td>2.75%</td></tr>
          <tr><td class="text-start">Earth Enhance</td><td>2.75%</td></tr>
          <tr><td class="text-start">Poison Enhance</td><td>2.75%</td></tr>
          <tr><td class="text-start">Holy Enhance</td><td>2.75%</td></tr>
          <tr><td class="text-start">Shadow Enhance</td><td>2.75%</td></tr>
          <tr><td class="text-start">Ghost Enhance</td><td>2.75%</td></tr>
          <tr><td class="text-start">Undead Enhance</td><td>2.75%</td></tr>
        </tbody>
      </table>
    `,


  };

  document.getElementById('citySelect').addEventListener('change', function () {
    const city = this.value;
    const container = document.getElementById('enchantData');

    if (city && enchantDataByCity[city]) {
      container.innerHTML = enchantDataByCity[city];
      container.style.display = 'block';
    } else {
      container.innerHTML = '';
      container.style.display = 'none';
    }
  });