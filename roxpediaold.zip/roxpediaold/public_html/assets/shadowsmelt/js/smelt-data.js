/* assets/shadowsmelt/js/smelt-data.js
 * Shadow Smelting yield tables for ROX — Luminary (White/Blue) & Horcrux (Gold).
 * Source: user-provided sheet/image. Values marked red in the sheet are kept as-is.
 */

window.SMELT_LEVELS = [25, 40, 50, 60, 70, 80, 90, 100, 110, 120];
window.SMELT_WEAPON_TYPES = ['1H', '2H', 'Shield', 'Dagger'];

/* ========= L U M I N A R Y  (White & Blue) =========
   keys: rarity -> weaponType -> level -> amount
*/
window.LUMINARY = {
  White: {
    '1H':    { 25: 12,  40: 24,  50: 60,  60: 60,  70: 120, 80: 300,  90: 300, 100: 450, 110: 300, 120: 375 },
    '2H':    { 25: 18,  40: 36,  50: 90,  60: 90,  70: 180, 80: 450,  90: 450, 100: 675, 110: 450, 120: 563 }, // 563 per sheet
    'Shield':{ 25:  6,  40: 12,  50: 15,  60: 30,  70:  60, 80: 150,  90: 150, 100: 225, 110: 150, 120: 188 }, // 15* & 188 per sheet
    'Dagger':{ 25:  9,  40: 18,  50: 45,  60: 45,  70:  90, 80: 225,  90: 225, 100: 338, 110: 225, 120: 282 }  // 338 & 282 per sheet
  },
  Blue: {
    '1H':    { 25: 40,  40:  80, 50: 200, 60: 200, 70:  400, 80: 1000, 90: 2000, 100: 1500, 110: 1000, 120: 1250 }, // 2000*
    '2H':    { 25: 60,  40: 120, 50: 300, 60: 300, 70:  600, 80: 1500, 90: 3000, 100: 2250, 110: 1500, 120: 1875 }, // 3000*
    'Shield':{ 25: 20,  40:  40, 50: 100, 60: 100, 70:  200, 80:  500, 90:  500, 100:  750, 110:  500, 120:  625 },
    'Dagger':{ 25: 30,  40:  60, 50: 150, 60: 150, 70:  300, 80:  750, 90: 1500, 100: 1125, 110:  750, 120:  944 }  // 1500*, 944
  }
};

/* ========= H O R C R U X  (Gold) =========
   keys: weaponType -> tier(T0..T6) -> amount
*/
window.HORCRUX = {
  '1H':    { T0:  300, T1:  600, T2:  750, T3: 1500, T4: 1125, T5: 1500, T6:  938 },
  '2H':    { T0:  450, T1:  900, T2: 1125, T3: 2250, T4: 1688, T5: 2250, T6: 1407 },
  'Shield':{ T0:  150, T1:  300, T2:  375, T3:  750, T4:  563, T5:  750, T6:  469 },
  'Dagger':{ T0:  225, T1:  450, T2:  562, T3: 1125, T4:  844, T5: 1125, T6:  704 }
};

/* ========= Helpers ========= */

/** Get Luminary amount (White/Blue).
 * @param {'White'|'Blue'} rarity
 * @param {'1H'|'2H'|'Shield'|'Dagger'} weaponType
 * @param {number} level  one of 25,40,50,60,70,80,90,100,110,120
 * @returns {number|null}
 */
window.getLuminaryAmount = function (rarity, weaponType, level) {
  const r = LUMINARY[rarity];
  if (!r) return null;
  const row = r[weaponType];
  if (!row) return null;
  return Number.isFinite(row[level]) ? row[level] : null;
};

/** Get Horcrux amount (Gold).
 * @param {'1H'|'2H'|'Shield'|'Dagger'} weaponType
 * @param {'T0'|'T1'|'T2'|'T3'|'T4'|'T5'|'T6'} tier
 * @returns {number|null}
 */
window.getHorcruxAmount = function (weaponType, tier) {
  const row = HORCRUX[weaponType];
  if (!row) return null;
  return Number.isFinite(row[tier]) ? row[tier] : null;
};

/* Convenience guard messages (optional) */
window.describeLuminaryMissing = (rarity, weaponType, level) =>
  `No Luminary yield found for ${rarity} ${weaponType} Lv.${level}. Check SMELT_LEVELS and LUMINARY table.`;

window.describeHorcruxMissing = (weaponType, tier) =>
  `No Horcrux yield found for ${weaponType} ${tier}. Check HORCRUX table.`;
